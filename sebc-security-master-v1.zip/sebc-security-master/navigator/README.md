# Cloudera Navigator

The Navigator demo on http://bvt-nav-1.vpc.cloudera.com:7180
